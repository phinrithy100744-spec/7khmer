const shopLat = 11.4665;
const shopLng = 104.8705;

// ======================
// 🗺 INIT MAP
// ======================
const map = L.map('map').setView([shopLat, shopLng], 15);

// tile layer
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19
}).addTo(map);

// shop marker
L.marker([shopLat, shopLng])
  .addTo(map)
  .bindPopup("🏪 MyShop Pro<br>📍 កំបូល ភ្នំពេញ")
  .openPopup();

// ======================
// 📍 GOOGLE MAP LINK FIX
// ======================
document.getElementById("openMap").href =
  `https://www.google.com/maps?q=${shopLat},${shopLng}`;

// ======================
// 📍 USER LOCATION (optional)
// ======================
function useMyLocation(){
  navigator.geolocation.getCurrentPosition(
    function(pos){
      const lat = pos.coords.latitude;
      const lng = pos.coords.longitude;

      L.marker([lat,lng]).addTo(map)
        .bindPopup("📍 អ្នកនៅទីនេះ")
        .openPopup();

      map.setView([lat,lng], 14);
    },
    function(err){
      alert("❌ មិនអាចយកទីតាំងបាន: " + err.message);
    }
  );
}